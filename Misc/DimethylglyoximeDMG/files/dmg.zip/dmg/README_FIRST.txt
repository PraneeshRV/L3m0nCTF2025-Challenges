# Dimethylglyoxime

*A disk encrypted, secrets deep inside,*  
*No hints, no mercy, nowhere left to hide.*  
*Three layers wait, with ciphers old and new,*  
*We'll see who can break it, who can find the truth.*

*When something's broken, time tells all,*  
*Seven segments light the way through the wall.*  
*Add what's counted to what's displayed,*  
*The pieces merge where foundations are laid.*

*When timestamps break and numbers show,*  
*Combine their secrets, let them flow.*  
*Seven segments hold a key,*  
*Add the moments, you'll be free.*

*In the end, all are broken.*
